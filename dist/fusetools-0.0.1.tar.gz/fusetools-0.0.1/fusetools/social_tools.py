class Twitter:
    # todo: implement
    pass


class LinkedIn:
    # todo: implement
    pass


class Facebook:
    # todo: implement
    pass


class Pinterest:
    # todo: implement
    pass


class Instagram:
    # todo: implement
    pass
