from setuptools import setup, find_packages

setup(
    name="fusetools",
    version="0.0.4",
    packages=["fusetools"],
    install_requires=["nbsphinx"]
)
